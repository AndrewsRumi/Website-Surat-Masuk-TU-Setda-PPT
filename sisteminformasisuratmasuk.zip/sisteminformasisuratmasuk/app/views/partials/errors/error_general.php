<div class="container">
	<div class="text-center">
		<p class="lead text-danger bold"><?php echo $this->view_data; ?></p>
	</div>
	<hr />
	<div class="text-center">
		<a href="<?php print_link(HOME_PAGE); ?>" class="btn btn-primary">Go to Home Page</a>
	</div>
</div>