<div class="container">
	<h4>Terms And Conditons</h4>
	<hr />
	<div>
		Put page content here
	</div>
	<?php 
		if(DEVELOPMENT_MODE){ 
	?>
		<small class="text-muted">To edit this file, browse to :- <i>app/view/partials/info/terms_and_conditions.php</i></small>
	<?php 
		} 
	?>
</div>